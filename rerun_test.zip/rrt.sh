#!/usr/bin/env bash

jq --null-input --arg i "$1" '
{
  rerun: 1,
  items: [{
    title: ("time: " + (now|strflocaltime("%r"))),
    subtitle: ("arg: " + $i)
  }]
}'
